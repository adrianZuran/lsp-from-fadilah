<?php

    include '../form/header.php';
    include '../function.php';

    if (isset($_POST['addVendor'])) {
        $nama_vendor = $_POST['nama_vendor'];
        $kontak = $_POST['kontak'];
        $nama_barang = $_POST['nama_barang'];
        addVendor($nama_vendor, $kontak, $nama_barang);
        echo '<script>alert ("Vendor berhasil ditambahkan");
        window.location.href = "../menu/vendor.php";
        </script>';
        exit;
    }
?>
<div class="d-flex justify-content-center mt-5">
    <div class="col-md-6 p-5 shadow-lg" style="border-radius: 10px; border: 1px solid #ccc">
        <h3>TAMBAHKAN VENDOR</h3><hr style="margin-bottom: 2rem;">
        <form action="addvendor.php" method="post">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Vendor</label>
                <input type="text" class="form-control" id="nama_vendor" name="nama_vendor" placeholder="Masukkan Nama Vendor">
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Kontak</label>
                <input type="text" class="form-control" id="kontak" name="kontak" placeholder="Masukkan kontak">
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" placeholder="Masukkan Nama Barang">
            </div>
            <button type="submit" name="addVendor" class="btn btn-primary w-100 mt-2">Masukkan</button>
        </form>
    </div>
</div>