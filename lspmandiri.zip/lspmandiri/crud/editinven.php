<?php
    include '../form/header.php';
    include '../function.php';

    if (isset($_GET['updateInv'])) {
        $id_inv = $_GET['updateInv'];
        $inv = getInvById($id_inv);
    }

    if (isset($_POST['update'])) {
        $id_inv = $_POST['id_inv'];
        $nama_barang = $_POST['nama_barang'];
        $stok = $_POST['stok'];
        $jenis_barang = $_POST['jenis_barang'];
        $barcode = $_POST['barcode'];
        $harga = $_POST['harga'];
        $id_vendor = $_POST['id_vendor'];
        $id_gudang = $_POST['id_gudang'];
        updateInv($id_inv, $nama_barang, $stok, $jenis_barang, $barcode, $harga, $id_vendor, $id_gudang);
        header('location: ../menu/inventory.php');
        exit;
    } 

    $vendors = getAllVendor();
    $vendors = array_column($vendors, null, 'id_vendor');
    $gudang = getAllGud();
?>



<div class="d-flex justify-content-center mt-5">
    <div class="col-md-6 p-5 shadow-lg" style="border-radius: 10px; border: 1px solid #ccc">
        <h3>TAMBAHKAN BARANG</h3><hr>
        <form action="editinven.php" method="post">
            <input type="hidden" name="id_inv" value="<?= $inv['id_vendor']?>">
            <input type="hidden" name="id_inv" value="<?= $inv['id_gudang']?>">
            <input type="hidden" name="id_inv" value="<?= $inv['id_inv']?>">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Barang</label>
                    <input type="text" name="nama_barang" id="nama_barang" class="form-control" value="<?= $inv['nama_barang'] ?>" 
                    readonly>
                </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Vendor</label>
                    <input type="text" name="nama_vendor" id="nama_vendor" class="form-select" 
                    value="<?= isset($vendors[$inv['id_vendor']]) ? $vendors[$inv['id_vendor']]['nama_vendor'] : 'gaada vendor'?>"
                    readonly>  
                    <input type="hidden" name="id_vendor" value="<?= $inv['id_vendor']?>">  
                </div>
                <div class="col-md-4">
                    <label for="name" class="form-label">Stok Barang</label>
                    <input type="text" class="form-control" id="stok" name="stok" value="<?= $inv['stok'] ?>">
                </div>
                <div class="col-md-4">
                    <label for="name" class="form-label">Jenis Barang</label>
                    <input type="text" class="form-control" id="jenis_barang" name="jenis_barang" value="<?= $inv['jenis_barang'] ?>">
                </div>
                <div class="col-md-4">
                    <label for="name" class="form-label">Barcode</label>
                    <input type="text" class="form-control" id="barcode" name="barcode" value="<?= $inv['barcode'] ?>">
                </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Harga</label>
                    <input type="text" class="form-control" id="harga" name="harga" value="<?= $inv['harga'] ?>">
                </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Gudang</label>
                    <select name="id_gudang" id="id_gudang" class="form-select">
                        <?php foreach ($gudang as $g) {?>
                            <option value="<?= $g['id_gudang'];?> "
                            <?=isset($inv['id_gudang']) && $inv['id_gudang'] == $g['id_gudang'] ? 'selected':'' ?>>
                            <?= $g['nama_gudang'] ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <button type="submit" name="update" class="btn btn-primary w-100 mt-2">Ubah</button>
            </div>
        </form>
    </div>
</div>