<?php

    include '../form/header.php';
    include '../function.php';

    if (isset($_GET['updateVendor'])) {
        $nama_vendor = $_GET['updateVendor'];
        $vendor = getVendorByname($nama_vendor);
    }

    if (isset($_POST['update'])) {
        $id_vendor = $_POST['id_vendor'];
        $nama_vendor = $_POST['nama_vendor'];
        $kontak = $_POST['kontak'];
        $nama_barang = $_POST['nama_barang'];
        updateVendor($id_vendor, $nama_vendor, $kontak, $nama_barang);
        header('location: ../menu/vendor.php');
        exit;
    }
?>
<div class="d-flex justify-content-center mt-5">
    <div class="col-md-6 p-5 shadow-lg" style="border-radius: 10px; border: 1px solid #ccc">
        <h3>TAMBAHKAN VENDOR</h3><hr style="margin-bottom: 2rem;">
        <form action="editvendor.php" method="post">
            <input type="hidden" name="id_vendor" value="<?= $vendor['id_vendor'];?>" required onchange="this.form.submit()">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Vendor</label>
                <input type="text" class="form-control" id="nama_vendor" name="nama_vendor" value="<?=$vendor['nama_vendor']?>" required>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Kontak</label>
                <input type="text" class="form-control" id="kontak" name="kontak" value="<?= $vendor['kontak'];?>" required>
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?= $vendor['nama_barang'];?>">
            </div>
            <button type="submit" name="update" class="btn btn-primary w-100 mt-2">Update</button>
        </form>
    </div>
</div>