<?php
     include '../form/header.php';
     include '../function.php';
 
     if (isset($_GET['updateGud'])) {
         $id_gudang = $_GET['updateGud'];
         $gudang = getGudById($id_gudang);
     }
     if (isset($_POST['update'])) {
        $id_gudang = $_POST['id_gudang'];
        $nama_gudang = $_POST['nama_gudang'];
        $lokasi = $_POST['lokasi'];
        updateGud($id_gudang, $nama_gudang, $lokasi);
        header('location:../menu/gudang.php');
        exit();
     }
?>
<div class="d-flex justify-content-center mt-5">
    <div class="col-md-6 p-5 shadow-lg" style="border-radius: 10px; border: 1px solid #ccc">
        <h3>EDIT GUDANG</h3><hr style="margin-bottom: 2rem;">
        <form action="editgud.php" method="post">
            <input type="hidden" name="id_gudang" value="<?=$gudang['id_gudang']?>">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Gudang</label>
                <input type="text" class="form-control" id="nama_gudang" name="nama_gudang" value="<?= $gudang['nama_gudang']?>">
            </div>
            <div class="mb-3">
                <label for="name" class="form-label">Lokasi</label>
                <input type="text" class="form-control" id="lokasi" name="lokasi" value="<?=$gudang['lokasi']?>">
            </div>
            <button type="submit" name="update" class="btn btn-primary w-100 mt-2">Masukkan</button>
        </form>
    </div>
</div>