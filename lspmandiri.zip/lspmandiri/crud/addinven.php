<?php
    include '../form/header.php';
    include '../function.php';

    $nama_barang = '';
    $nama_vendor = '';
    $id_gudang = '';

    if (isset($_POST['addInv'])) {
        $nama_vendor = $_POST['nama_vendor'];
        $nama_barang = $_POST['nama_barang'];
        $stok = $_POST['stok'];
        $jenis_barang = $_POST['jenis_barang']; 
        $barcode = $_POST['barcode'];
        $harga = $_POST['harga'];
        $id_gudang = $_POST['id_gudang'];

        $vendor = getVendorByname($nama_vendor);
        if ($vendor) {
            $id_vendor = $vendor['id_vendor'];
            if (addInv($nama_barang, $stok, $jenis_barang, $barcode, $harga, $id_vendor, $id_gudang) == true) {
                $_SESSION['data_behasil'] = "data berhasil ditambahkan";
                header('location: ../menu/inventory.php');
                exit();
            }else{
                echo "<script>alert('Vendor gagal dimasukkan')</script>";
            }
        }
    }
    $vendors = getAllVendor();
    $gudang = getAllGud();

    $unique_barang =[];
    foreach ($vendors as $ven) {
        $unique_barang[$ven['nama_barang']]=$ven;
    }

    $barang_vendor =[];
    if (isset($_POST['nama_barang'])) {
        $nama_barang = $_POST['nama_barang'];
        $barang_vendor = getVendorByBarangName($nama_barang);
    }
?>
<div class="d-flex justify-content-center mt-5">
    <div class="col-md-6 p-5 shadow-lg" style="border-radius: 10px; border: 1px solid #ccc">
        <h3>TAMBAHKAN BARANG</h3><hr>
        <form action="addinven.php" method="post">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Barang</label>
                    <select name="nama_barang" id="nama_barang" class="form-select" onchange="this.form.submit()">
                        <?php foreach ($unique_barang as $ven) {?>
                            <option value="<?= $ven['nama_barang'];?>" <?= $nama_barang == $ven['nama_barang'] ? 'selected':'' ?> >
                                <?= $ven['nama_barang'] ?>
                            </option>
                            <?php } ?>
                        </select>
                    </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Vendor</label>
                    <select name="nama_vendor" id="nama_vendor" class="form-select">
                        <?php foreach ($barang_vendor as $ba) {?>
                            <option value="<?= $ba['nama_vendor'];?>" <?= $nama_vendor == $ba['nama_vendor'] ? 'selected':'' ?>>
                                <?= $ba['nama_vendor'] ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="name" class="form-label">Stok Barang</label>
                    <input type="text" class="form-control" id="stok" name="stok" placeholder="Masukkan stok">
                </div>
                <div class="col-md-4">
                    <label for="name" class="form-label">Jenis Barang</label>
                    <input type="text" class="form-control" id="jenis_barang" name="jenis_barang" placeholder="Jenis Barang">
                </div>
                <div class="col-md-4">
                    <label for="name" class="form-label">Barcode</label>
                    <input type="text" class="form-control" id="barcode" name="barcode" placeholder="Barcode">
                </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Harga</label>
                    <input type="text" class="form-control" id="harga" name="harga" placeholder="Masukkan Harga">
                </div>
                <div class="col-md-6">
                    <label for="name" class="form-label">Nama Gudang</label>
                    <select name="id_gudang" id="id_gudang" class="form-select">
                        <?php foreach ($gudang as $g) {?>
                            <option value="<?= $g['id_gudang'];?> <?= $id_gudang == $g['id_gudang'] ? 'selected':'' ?>">
                                <?= $g['nama_gudang'] ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
                <button type="submit" name="addInv" class="btn btn-primary w-100 mt-2">Masukkan</button>
            </div>
        </form>
    </div>
</div>