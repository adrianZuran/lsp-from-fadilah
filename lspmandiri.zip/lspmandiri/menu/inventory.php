<?php
    include '../form/header.php';
    include '../form/sidebar.php';
    include '../function.php';

    $inv = getAllInv();

     if (isset($_GET['delete'])) {
        $id_inv = $_GET['delete'];
        deleteInv($id_inv);
        header('location: inventory.php');
        exit;
    }

?>
<div class="col-md-10 p-5">
    <div class="d-flex justify-content-between align-items-center p-4">
        <h3><b>DAFTAR INVENTORY</b></h3>
        <div class="d-flex gap-2">
        <a href="../crud/addinven.php" class="btn btn-primary" >Tambah</a>
        <a href="inventory.php" class="btn btn-warning" style="margin-right: 3rem;">Refresh</a>
        </div>
    </div>
    <?php $alert = false;
    foreach ($inv as $i):?>
        <?php if($i['stok'] == 0 AND !$alert):?>
            <div class="alert alert-danger">
                <h5>ADA STOK KOSONG!</h5>
            </div>
        <?php $alert = true; ?>
        <?php endif;?>
    <?php endforeach;?>
    <table class="table table-bordered table-striped table-hover shadow-lg-5">
        <tr class="text-center table-primary">
            <th>No</th>
            <!-- <th>Vendor</th> -->
            <th>Nama Barang</th>
            <th>Stok</th>
            <th>Harga</th>
            <th>Lokasi</th>
            <th>Action</th>
        </tr>
        <?php $no = 1;
            foreach ($inv as $i):
        ?>
        <tr class="<?= $i['stok'] == 0 ? 'table-danger' : ''?>">
            <td><?= $no++ ?></td>
            <!-- <td><?= $i['nama_vendor']; ?></td> -->
            <td><?= $i['nama_barang']; ?></td>
            <td><?= $i['stok']; ?></td>
            <td><?= $i['harga']; ?></td>
            <td><?= $i['nama_gudang']; ?></td>
            <td>
                <a href="../crud/editinven.php?updateInv=<?= $i['id_inv']; ?>" class="btn btn-warning">EDIT</a>
                <a href="inventory.php?delete=<?= $i['id_inv']?>" class="btn btn-danger">DELETE</a>
            </td>
        </tr>
       <?php endforeach;?>
    </table>
</div>
