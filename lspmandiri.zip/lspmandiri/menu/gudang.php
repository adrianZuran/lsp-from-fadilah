<?php
    include '../function.php';
    include '../form/header.php';
    include '../form/sidebar.php';

    $gudang = getAllGud();

    if (isset($_GET['delete'])) {
        $id_gudang = $_GET['delete'];
        deleteGud($id_gudang);
        header('location:gudang.php');
        exit();
    }
?>
<div class="col-md-10 p-4 me-auto ms-auto">
    <div class="d-flex justify-content-between align-items-center p-4">
        <h3><b>DAFTAR GUDANG</b></h3>
        <a href="../crud/addgud.php" class="btn btn-primary" style="margin-right: 3rem;">Tambah</a>
    </div>
    <table class="table table-bordered table-striped table-hover shadow-lg-5">
        <tr class="text-center table-primary">
            <th>No</th>
            <th>Nama Gudang</th>
            <th>Lokasi</th>
            <th>Action</th>
        </tr>
        <?php $no = 1;
            foreach ($gudang as $g):
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $g['nama_gudang']; ?></td>
            <td><?= $g['lokasi']; ?></td>
            <td>
                <a href="../crud/editgud.php?updateGud=<?=$g['id_gudang']?>" class="btn btn-warning">EDIT</a>
                <a href="gudang.php?delete=<?=$g['id_gudang']?>" class="btn btn-danger">DELETE</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
