<?php
    include '../function.php';
    include '../form/header.php';
    include '../form/sidebar.php';

    $vendor = getAllVendor();

    if (isset($_GET['delete'])) {
        $id_vendor = $_GET['delete'];
        deleteVendor($id_vendor);
        header('location: vendor.php');
        exit;
    }

?>
<div class="col-md-10 p-4">
    <div class="d-flex justify-content-between align-items-center p-4">
        <h3><b>DAFTAR VENDOR</b></h3>
        <a href="../crud/addvendor.php" class="btn btn-primary" style="margin-right: 3rem;">Tambah</a>
    </div>
    <table class="table table-bordered table-striped table-hover shadow-lg-5">
        <tr class="text-center table-primary">
            <th>No</th>
            <th>Nama Vendor</th>
            <th>Kontak</th>
            <th>Nama Barang</th>
            <th>Action</th>
        </tr>
        <?php $no = 1;
            foreach ($vendor as $ven):
        ?>
        <tr>
            <td><?= $no++ ?></td>
            <td><?= $ven['nama_vendor']; ?></td>
            <td><?= $ven['kontak']; ?></td>
            <td><?= $ven['nama_barang']; ?></td>
            <td>
                <a href="../crud/editvendor.php?updateVendor=<?= $ven['nama_vendor']; ?>" class="btn btn-warning">EDIT</a>
                <a href="vendor.php?delete=<?= $ven['id_vendor']; ?>" class="btn btn-danger">DELETE</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
