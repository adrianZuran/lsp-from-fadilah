<div class="container-fluid">
    <div class="row">
        <div class="col-md-2 bg-primary" style="min-height: 91.3vh;">
            <ul class="nav flex-column mb-5">
                <li class="nav-item mt-4">
                    <a href="../dashboard.php" class="nav-link text-white ps-0" style="margin-left: 1em;"><h5>Dashboard</h5></a>
                    <hr class="bg-secondary">
                </li>
                <li class="nav-item">
                    <a href="http://localhost/lspmandiri/menu/vendor.php" class="nav-link text-white ps-0" style="margin-left: 1em;"><h5>Vendor</h5></a>
                    <hr class="bg-secondary">
                </li>
                <li class="nav-item">
                    <a href="http://localhost/lspmandiri/menu/inventory.php" class="nav-link text-white ps-0" style="margin-left: 1em;"><h5>Inventory</h5></a>
                    <hr class="bg-secondary">
                </li>
                <li class="nav-item">
                    <a href="http://localhost/lspmandiri/menu/gudang.php" class="nav-link text-white ps-0" style="margin-left: 1em;"><h5>Gudang</h5></a>
                    <hr class="bg-secondary">
                </li>
            </ul>
        </div>
        