<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="http://localhost/lspmandiri/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="http://localhost/lspmandiri/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://localhost/lspmandiri/bootstrap/js/bootstrap.js">

    <style>
        .navbar-brand{
            margin-left: 2rem;
        }
        .navbar-nav{
            margin-left: 10rem;
            font-size: 1.2em;
        }
        /* .nav-item{
            margin-left: 2rem;
        } */
        .nav-but{
            margin-left: 45rem;
            display: flex;
            align-items: center;
        }
    </style>
</head>
<body>
    <header class="navbar navbar-expand-md navbar-dark bg-primary">
        <div class="container-fluid">
            <a href="dashboard.php" class="navbar-brand"><b>INVENTORY MANAGEMENT</b></a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-but">
                        <a href="http://localhost/lspmandiri/logout.php" class="btn btn-dark text-white">LogOut</a>
                    </li>
                </ul>
            </div>
        </div>
    </header>