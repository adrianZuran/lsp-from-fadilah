<?php
    $conn= mysqli_connect("localhost","root","","lspfix");

    if (!$conn) {
        die ("koneksi gagal".mysqli_connect().mysqli_connect_error());
    }
?>