<?php
    include 'koneksi.php';

// login

// login end

// vendor
function addVendor($nama_vendor, $kontak, $nama_barang){
    global $conn;
    $query = "INSERT INTO vendor (nama_vendor, kontak, nama_barang) VALUES (?,?,?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sis', $nama_vendor, $kontak, $nama_barang);
    $stmt->execute();
}
function getAllVendor(){
    global $conn;
    $query = "SELECT * FROM vendor";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
function deleteVendor($id_vendor){
    global $conn;
    $query = "DELETE FROM vendor WHERE id_vendor = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_vendor);
    $stmt->execute();
}
function getVendorByname($nama_vendor){
    global $conn;
    $query = "SELECT * FROM vendor WHERE nama_vendor = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $nama_vendor);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
function getVendorById($id_vendor){
    global $conn;
    $query = "SELECT * FROM vendor WHERE id_vendor = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_vendor);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
function updateVendor($id_vendor, $nama_vendor, $kontak, $nama_barang){
    global $conn;
    $query = "UPDATE vendor 
            SET nama_vendor= ?, kontak = ?, nama_barang = ? 
            WHERE id_vendor = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sisi', $nama_vendor, $kontak, $nama_barang, $id_vendor);
    $stmt->execute();
}
// vendor end
// invetory
function addInv($nama_barang, $stok, $jenis_barang, $barcode, $harga, $id_vendor, $id_gudang){
    global $conn;
    $query = "INSERT INTO inventory 
    (nama_barang, stok, jenis_barang, barcode, harga, id_vendor, id_gudang) VALUES (?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sisiiii', $nama_barang, $stok, $jenis_barang, $barcode, $harga, $id_vendor, $id_gudang);
    $stmt->execute();
    return true;
}
function getAllInv(){
    global $conn;
    $query = "SELECT inventory.*, gudang.nama_gudang AS nama_gudang, vendor.nama_vendor AS nama_vendor
            FROM inventory
            JOIN gudang ON inventory.id_gudang = gudang.id_gudang
            JOIN vendor ON inventory.id_vendor = vendor.id_vendor";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
function deleteInv($id_inv){
    global $conn;
    $query = "DELETE FROM inventory WHERE id_inv = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_inv);
    $stmt->execute();
}
function getBarangByname($nama_barang){
    global $conn;
    $query = "SELECT * FROM vendor WHERE nama_barang = ? ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $nama_barang);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
function getVendorByBarangName($nama_barang){
    global $conn;
    $query = "SELECT nama_vendor FROM vendor WHERE nama_barang = ? ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $nama_barang);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
function getInvById($id_inv){
    global $conn;
    $query = "SELECT * FROM inventory WHERE id_inv = ? ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_inv);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
function updateInv($id_inv, $nama_barang, $stok, $jenis_barang, $barcode, $harga, $id_vendor, $id_gudang){
    global $conn;
    $query = "UPDATE inventory SET 
            nama_barang = ?, stok = ?, jenis_barang = ?, barcode = ?, harga = ?, id_vendor = ?, id_gudang = ? 
            WHERE id_inv = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('sisiiiii', $nama_barang, $stok, $jenis_barang, $barcode, $harga, $id_vendor, $id_gudang, $id_inv);
    $stmt->execute();
}
// inven end
// gudang
function addGud($nama_gudang, $lokasi){
    global $conn;
    $query = "INSERT INTO gudang 
    (nama_gudang, lokasi) VALUES (?,?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ss', $nama_gudang, $lokasi);
    $stmt->execute();
}   

function getAllGud(){
    global $conn;
    $query = "SELECT * FROM gudang";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}
function getGudById($id_gudang){
    global $conn;
    $query = "SELECT * FROM gudang WHERE id_gudang = ? ";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_gudang);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}
function updateGud($id_gudang, $nama_gudang, $lokasi){
    global $conn;
    $query = "UPDATE gudang SET  
            nama_gudang = ?, lokasi = ? 
            WHERE id_gudang = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ssi', $nama_gudang, $lokasi, $id_gudang);
    $stmt->execute();
}
function deleteGud($id_gudang){
    global $conn;
    $query = "DELETE FROM gudang WHERE id_gudang = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id_gudang);
    $stmt->execute();
}

// gudang end
?>