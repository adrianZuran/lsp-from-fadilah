<?php
    session_start();
    if (!isset($_SESSION['admin'])) {
        header('location: http://localhost/lspmandiri/login.php');
        exit();
    }

    include 'form/header.php';
    include 'form/sidebar.php';
?>
    <!-- main -->
    <div class="col-md-10 p-4">
            <h3><b>Hallo, Admin!</b></h3>
            <div class="row">
                <div class="card bg-danger mt-4 px-4" style="width: 18rem; margin-left:2rem">
                    <div class="card-body">
                        <h5 class="tittle">STOCK BARANG</h5>
                        <a href="menu/inventory.php" style="text-decoration: none;"><p class="text-white">Lihat Detail</p></a>
                    </div>
                </div>
                <div class="card bg-warning mt-4 px-4" style="width: 18rem; margin-left:4rem">
                    <div class="card-body">
                        <h5 class="tittle">SUPPLIER</h5>
                        <a href="menu/vendor.php" style="text-decoration: none;"><p class="text-white">Lihat Detail</p></a>
                    </div>
                </div>
                <div class="card bg-danger mt-4 px-4" style="width: 18rem; margin-left:4rem">
                    <div class="card-body">
                        <h5 class="tittle">LOCATION</h5>
                        <a href="menu/gudang.php" style="text-decoration: none;"><p class="text-white">Lihat Detail</p></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    include 'form/footer.php';
?>

