<?php
  session_start();
    include 'koneksi.php';

    if (isset($_POST['login'])) {
      $email = $_POST['email'];
      $password = $_POST['password'];

      global $conn;
      $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ? AND password = ?");
      $stmt->bind_param('ss', $email, $password);
      $stmt->execute();
      $result = $stmt->get_result();
      $admin = $result->fetch_assoc();
      if ($result->num_rows == 1) {
        $_SESSION['admin']=$admin;
        header('location: dashboard.php');
        exit();
      }
    }
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <!-- Link Bootstrap CSS -->
    <link rel="stylesheet" href="http://localhost/lspmandiri/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="http://localhost/lspmandiri/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://localhost/lspmandiri/bootstrap/js/bootstrap.js">
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card p-4" style="width: 100%; max-width: 400px;">
            <h3 class="text-center mb-4">Login</h3>
            <form action="login.php" method="post">
                <div class="mb-3">
                    <label for="email" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="email" placeholder="Enter your email" name="email">
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" placeholder="Enter your password" name="password">
                </div>
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary" name="login">Login</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>